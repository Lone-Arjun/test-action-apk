import { motion } from "framer-motion";
import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ErrorScreenProps {
  onRetry: () => void;
  onGoHome: () => void;
}

export default function ErrorScreen({ onRetry, onGoHome }: ErrorScreenProps) {
  return (
    <motion.div
      className="fixed inset-0 bg-slate-900 flex items-center justify-center"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5 }}
    >
      <div className="text-center space-y-6 p-8 max-w-md mx-auto">
        {/* Error Icon */}
        <motion.div
          className="w-24 h-24 mx-auto bg-red-500/10 rounded-full flex items-center justify-center"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring" }}
        >
          <AlertTriangle className="w-12 h-12 text-red-500" />
        </motion.div>
        
        {/* Error Message */}
        <motion.div
          className="space-y-3"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <h2 className="text-2xl font-semibold text-slate-100">Oops! Something went wrong</h2>
          <p className="text-slate-400 leading-relaxed">
            Unable to load the application. This might be due to a server error or network issue.
          </p>
        </motion.div>
        
        {/* Action Buttons */}
        <motion.div
          className="space-y-3"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          <Button
            onClick={onRetry}
            className="w-full bg-gradient-to-r from-purple-500 to-cyan-500 hover:from-purple-600 hover:to-cyan-600 text-white font-medium py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-105"
          >
            Retry
          </Button>
          <Button
            onClick={onGoHome}
            variant="secondary"
            className="w-full bg-slate-700 hover:bg-slate-600 text-slate-200 font-medium py-3 px-6 rounded-lg transition-all duration-200"
          >
            Go to Dashboard
          </Button>
        </motion.div>
        
        {/* Support Message */}
        <motion.p
          className="text-sm text-slate-500"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
        >
          If you believe this is an error, please contact support.
        </motion.p>
      </div>
    </motion.div>
  );
}
