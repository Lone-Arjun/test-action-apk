import { motion } from "framer-motion";
import { WifiOff } from "lucide-react";
import { Button } from "@/components/ui/button";

interface OfflineScreenProps {
  onRetry: () => void;
  isOnline: boolean;
}

export default function OfflineScreen({ onRetry, isOnline }: OfflineScreenProps) {
  return (
    <motion.div
      className="fixed inset-0 bg-slate-900 flex items-center justify-center"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5 }}
    >
      <div className="text-center space-y-6 p-8 max-w-md mx-auto">
        {/* Offline Icon */}
        <motion.div
          className="w-24 h-24 mx-auto bg-slate-800 rounded-full flex items-center justify-center"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring" }}
        >
          <WifiOff className="w-12 h-12 text-slate-400" />
        </motion.div>
        
        {/* Message */}
        <motion.div
          className="space-y-3"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <h2 className="text-2xl font-semibold text-slate-100">No Internet Connection</h2>
          <p className="text-slate-400 leading-relaxed">
            Please check your connection and try again. Make sure you're connected to the internet.
          </p>
        </motion.div>
        
        {/* Retry Button */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          <Button
            onClick={onRetry}
            className="w-full bg-gradient-to-r from-purple-500 to-cyan-500 hover:from-purple-600 hover:to-cyan-600 text-white font-medium py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-105"
          >
            Try Again
          </Button>
        </motion.div>
        
        {/* Network Status */}
        <motion.div
          className="flex items-center justify-center space-x-2 text-sm text-slate-500"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
        >
          <div className={`w-2 h-2 rounded-full ${isOnline ? 'bg-green-500' : 'bg-red-500'}`}></div>
          <span>{isOnline ? 'Online' : 'Offline'}</span>
        </motion.div>
      </div>
    </motion.div>
  );
}
