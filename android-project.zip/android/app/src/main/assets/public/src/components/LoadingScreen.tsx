import { motion } from "framer-motion";
import { Zap } from "lucide-react";

interface LoadingScreenProps {
  progress: number;
}

export default function LoadingScreen({ progress }: LoadingScreenProps) {
  const circumference = 2 * Math.PI * 45;
  const offset = circumference - (progress / 100) * circumference;

  return (
    <motion.div
      className="fixed inset-0 flex items-center justify-center gradient-bg"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="text-center space-y-8">
        {/* App Logo/Icon */}
        <motion.div
          className="w-24 h-24 mx-auto bg-white/20 rounded-3xl flex items-center justify-center backdrop-blur-sm animate-bounce-subtle"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
        >
          <Zap className="w-12 h-12 text-white" />
        </motion.div>
        
        {/* App Name */}
        <motion.div
          className="space-y-2"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <h1 className="text-3xl font-bold text-white">Builder Engine</h1>
          <p className="text-white/80 text-lg">Loading your workspace...</p>
        </motion.div>
        
        {/* Progress Ring */}
        <motion.div
          className="relative"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.6, type: "spring" }}
        >
          <svg className="progress-ring w-20 h-20 mx-auto" viewBox="0 0 100 100">
            <circle
              className="text-white/20"
              stroke="currentColor"
              strokeWidth="4"
              cx="50"
              cy="50"
              r="45"
              fill="transparent"
            />
            <circle
              className="progress-ring-circle text-white"
              stroke="currentColor"
              strokeWidth="4"
              cx="50"
              cy="50"
              r="45"
              fill="transparent"
              style={{ strokeDashoffset: offset }}
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-white font-semibold text-lg">
              {Math.round(progress)}%
            </span>
          </div>
        </motion.div>
        
        {/* Loading Animation */}
        <motion.div
          className="loading-dots mx-auto"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
        >
          <div></div>
          <div></div>
          <div></div>
          <div></div>
        </motion.div>
      </div>
    </motion.div>
  );
}