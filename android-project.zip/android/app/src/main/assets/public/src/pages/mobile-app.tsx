import { useState, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Loader2, Zap, Database, Cloud, Server } from "lucide-react";

type AppState = 'loading' | 'loaded';

const BUILDER_ENGINE_URL = 'https://builderengine.vercel.app/login';

export default function MobileApp() {
  const [appState, setAppState] = useState<AppState>('loading');

  useEffect(() => {
  const timer = setTimeout(() => {
    setAppState('loaded');
  }, 2000);

  return () => clearTimeout(timer);
}, []);

  return (
    <div className="min-h-screen relative bg-slate-900 text-slate-100">
      <AnimatePresence mode="wait">
        {appState === 'loading' && (
          <motion.div
            key="loading"
            className="fixed inset-0 bg-slate-900 flex items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="text-center space-y-6 p-8">
              {/* Loading Icon */}
              <motion.div
                className="w-16 h-16 mx-auto bg-slate-800 rounded-full flex items-center justify-center"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: "spring" }}
              >
                <Zap className="w-8 h-8 text-purple-400" />
              </motion.div>
              
              {/* Loading Message */}
              <motion.div
                className="space-y-2"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.4 }}
              >
                <h2 className="text-xl font-semibold text-slate-100">Builder Engine</h2>
                <p className="text-slate-400">Loading...</p>
              </motion.div>

              {/* Animated Icons */}
              <motion.div
                className="flex justify-center space-x-4 mt-8"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.6 }}
              >
                <motion.div
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 2, repeat: Infinity, delay: 0 }}
                >
                  <Database className="w-6 h-6 text-blue-400" />
                </motion.div>
                <motion.div
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 2, repeat: Infinity, delay: 0.3 }}
                >
                  <Cloud className="w-6 h-6 text-green-400" />
                </motion.div>
                <motion.div
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 2, repeat: Infinity, delay: 0.6 }}
                >
                  <Server className="w-6 h-6 text-orange-400" />
                </motion.div>
              </motion.div>
            </div>
          </motion.div>
        )}
        
        {appState === 'loaded' && (
          <motion.div
            key="webview"
            className="fixed inset-0"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <iframe
              src={BUILDER_ENGINE_URL}
              className="w-full h-full border-none"
              title="Builder Engine Application"
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
