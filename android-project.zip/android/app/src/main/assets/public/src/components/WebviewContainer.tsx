import { motion } from "framer-motion";
import { useState, useEffect } from "react";

interface WebviewContainerProps {
  url: string;
}

export default function WebviewContainer({ url }: WebviewContainerProps) {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Fallback timeout for iframe loading
    const timeout = setTimeout(() => {
      setIsLoading(false);
    }, 5000);

    return () => clearTimeout(timeout);
  }, []);

  const handleIframeLoad = () => {
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  };

  const handleIframeError = () => {
    setIsLoading(false);
  };

  return (
    <motion.div
      className="fixed inset-0"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <iframe
        src={url}
        className="w-full h-full border-none"
        onLoad={handleIframeLoad}
        onError={handleIframeError}
        title="Builder Engine Application"
      />
      
      {/* Loading Overlay for Webview */}
      {isLoading && (
        <motion.div
          className="absolute inset-0 bg-slate-900 flex items-center justify-center"
          initial={{ opacity: 1 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="text-center space-y-4">
            <div className="w-16 h-16 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin mx-auto"></div>
            <p className="text-slate-400">Loading application...</p>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}
